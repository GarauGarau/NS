/* ============================================== */
/* APPLICATION LOGIC - app.js */
/* ============================================== */

// --- Core Functions (Home Page: Typewriter Effect) ---

/**
 * Implements the typewriter effect on the name.
 */
function startTypingEffect() {
    const typingElement = document.getElementById('typing-text');
    const cursorElement = document.getElementById('cursor');
    const text = APP_NAME;
    let i = 0;
    let speed = 150; // Typing speed in ms

    // Removes the blinking-cursor class for the duration of the typing
    cursorElement.classList.remove('blinking-cursor');

    function type() {
        if (i < text.length) {
            typingElement.textContent += text.charAt(i);
            i++;
            setTimeout(type, speed);
        } else {
            // Re-adds the blinking cursor when typing is finished
            setTimeout(() => {
                cursorElement.classList.add('blinking-cursor');
            }, 500);
        }
    }
    
    typingElement.textContent = ""; // Ensures it's empty before starting
    type();
}

// --- Core Functions (Research Page: Data Rendering) ---

/**
 * Generates the HTML for a single paper item.
 * @param {object} paper - The paper data.
 * @param {number} index - The paper's index.
 * @returns {string} - The HTML fragment.
 */
function renderPaperItem(paper, index) {
    // Unique ID to link the title and description
    const id = 'paper-' + index + '-' + paper.title.toLowerCase().replace(/[^a-z0-9]/g, '-');

    return `
        <div class="border-b border-gray-200 pb-2">
            <div class="flex items-start justify-between cursor-pointer" onclick="togglePaper('${id}')">
                <!-- Title and Expand Button -->
                <p class="text-sm md:text-base hover:text-yellow-600 transition-colors flex-1 pr-4">
                    <span id="icon-${id}" class="inline-block w-4 text-yellow-600 font-bold select-none transition-transform duration-300 transform translate-x-0 mr-2">[+]</span> 
                    ${paper.title}
                </p>
            </div>
            <!-- Expandable Description -->
            <div id="${id}" class="paper-description text-xs text-gray-600 ml-6">
                ${paper.description}
                <p class="pt-4 text-black">
                    <a href="${paper.draftLink}" target="_blank" class="text-sm border-b border-dotted border-black hover:text-yellow-600 hover:border-yellow-600">
                        Draft / Link 
                        <i data-lucide="external-link" class="w-3 h-3 inline-block ml-1"></i>
                    </a>
                </p>
            </div>
        </div>
    `;
}

/**
 * Injects paper data into the HTML.
 */
function loadResearchContent() {
    const pubList = document.getElementById('publications-list');
    const workPList = document.getElementById('working-papers-list');
    const wipList = document.getElementById('work-in-progress-list');

    pubList.innerHTML = researchData.publications.map(renderPaperItem).join('');
    workPList.innerHTML = researchData.workingPapers.map((p, i) => renderPaperItem(p, i + researchData.publications.length)).join('');
    wipList.innerHTML = researchData.workInProgress.map((p, i) => renderPaperItem(p, i + researchData.publications.length + researchData.workingPapers.length)).join('');

    // Replaces Lucide icons for Research page
    lucide.createIcons();
}

// Global function for paper expansion/collapse
window.togglePaper = function(id) {
    const descriptionDiv = document.getElementById(id);
    const iconSpan = document.getElementById(`icon-${id}`);
    
    if (descriptionDiv.classList.contains('expanded')) {
        descriptionDiv.classList.remove('expanded');
        iconSpan.textContent = '[+]';
        iconSpan.classList.remove('rotate-45');
    } else {
        descriptionDiv.classList.add('expanded');
        iconSpan.textContent = '[-]';
        iconSpan.classList.add('rotate-45');
    }
}


// --- Core Functions (Routing Logic) ---

/**
 * Handles URL hash-based routing.
 */
function handleRouting() {
    const hash = window.location.hash || '#home';
    const homePage = document.getElementById('home-page');
    const researchPage = document.getElementById('research-page');
    const cvPage = document.getElementById('cv-page');

    // Hides all pages
    homePage.classList.add('hidden');
    researchPage.classList.add('hidden');
    cvPage.classList.add('hidden');
    
    // Hides the cursor when not on the home page
    document.getElementById('cursor').style.display = 'none';

    // Shows the correct page based on the hash
    if (hash.startsWith('#research')) {
        researchPage.classList.remove('hidden');
        document.title = `${APP_NAME} | Research`;
    } else if (hash.startsWith('#cv')) {
        cvPage.classList.remove('hidden');
        document.title = `${APP_NAME} | CV`;
        // Ensures icons on CV page are rendered (like download icon)
        lucide.createIcons();
    } else {
        homePage.classList.remove('hidden');
        document.title = `${APP_NAME} | Home`;
        // Restarts the typewriter effect (if not already active)
        startTypingEffect(); 
        document.getElementById('cursor').style.display = 'inline-block';
    }
}

// --- Initialization ---
window.addEventListener('hashchange', handleRouting);

window.onload = function() {
    // 1. Load data and render content for the Research section
    loadResearchContent();
    // 2. Handle initial page view based on URL hash
    handleRouting();
    // 3. Ensure all Lucide icons across all pages are rendered
    lucide.createIcons();
};
