/* ============================================== */
/* DATA CONFIGURATION - data.js */
/* ============================================== */

// --- Data Configuration (Data Modularity) ---
const APP_NAME = "Alessio Garau"; // Replace with your name

const researchData = {
    publications: [
        { 
            title: "Publication Title One: A Minimalist Analysis of Web Aesthetics (2024)", 
            description: "Brief description of Publication One: This work explores the evolution of minimalist web design and the impact of 'dark mode' aesthetics on user experience and accessibility. Comment: This is the first peer-reviewed publication. Published in the Journal of Digital Arts.", 
            draftLink: "https://link-to-publication-one.com" 
        },
        { 
            title: "Computational Theories of the Blinking Cursor: History and Future", 
            description: "Brief description of Publication Two: An in-depth study of the symbolic significance of the block cursor and its persistence in the modern user interface as an element of attention and interaction. Comment: Important work on Human-Computer Interaction.", 
            draftLink: "https://link-to-publication-two.com" 
        },
    ],
    workingPapers: [
        { 
            title: "Working Paper Alpha: Single-File Architectures for Web Projects (Draft)", 
            description: "Description of Working Paper Alpha: Research on how 'single-file' architectures can simplify development, reduce setup time, and improve prototype portability. Comment: Currently under review and update. Will be presented at Conference X.", 
            draftLink: "https://link-to-working-paper-alpha.com" 
        },
        { 
            title: "Working Paper Beta: The Impact of Monospace Fonts on Learning", 
            description: "Description of Working Paper Beta: Preliminary research examining whether and how the use of fixed-width (monospace) fonts in educational materials can influence concentration and memorization in programming students.", 
            draftLink: "https://link-to-working-paper-beta.com" 
        },
    ],
    workInProgress: [
        { 
            title: "Work in Progress 1: Project Z - An Algorithm for Aesthetic Sorting", 
            description: "Development of a new sorting algorithm that evaluates not only time efficiency but also the visual 'pleasantness' of the sorting sequence.", 
            draftLink: "#" 
        },
        { 
            title: "Work in Progress 2: Digital Texture Analysis", 
            description: "Study on the integration of subtle textures and patterns (like 'noise' or 'grain') to improve the perception of depth and warmth in otherwise minimal user interfaces.", 
            draftLink: "#" 
        },
    ]
};
